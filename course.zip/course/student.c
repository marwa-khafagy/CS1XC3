/**
 * @file student.c
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This function will increment the num_grades variable in student by one, and add grade to the array
 * of grades in student
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  /**
   * @brief in this if statement calloc is used to request a block of memory on the heap 
   * (so that we can resize it with realloc later)
   * 
   */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  /**
   * @brief on the other hand, if the if condition isn't true, 
   * realloc will resize the array to the new number of grades (which is num_grades)
   * 
   */
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  /**
   * @brief next, we assign the new grade to the last element of the grades array
   * 
   */
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This function finds the average of all of the grades in the grades array 
 * 
 * @param student 
 * @return total / ((double) student->num_grades) 
 */
double average(Student* student)
{
  /**
   * @brief if there are no grades in the array (aka num_grades = 0), then zero is returned as it is the average
   * 
   */
  if (student->num_grades == 0) return 0;

  double total = 0;
  /**
   * @brief this for loop will go through all of the elements in the array grades 
   * and add them to the variable total
   * 
   */
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  /**
   * @brief the total found in the for loop divided by the number of grades (num_grades) is returned
   * 
   */
  return total / ((double) student->num_grades);
}

/**
 * @brief This function will print the information of student in an understandable manner
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  /**
   * @brief this for loop will go through each grade in the grades array and print it
   * 
   */
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function will generate a relativly random student, with a random first and last name, id, 
 * and grades (by using the amount of grades given to generate random grades)  
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  /**
   * @brief the following first_names and last_names arrays are arrays of names
   * that are then used later used to generate a random name and are assigned 
   * to the first_name and last_name variables in student using strcpy
   * 
   */
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  /**
   * @brief this for loop generates random digits (which will either be 4 or 5) and assigns them to id, and after the loop terminates, the last element of is is assigned to the null terminator
   * 
   */
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /**
   * @brief this for loop generates random grades (the lowest being 25 and the highest being 99) and calls the add_grade function to add that grade to grades
   * 
   */
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}