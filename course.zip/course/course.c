/**
 * @file course.c
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This function will increment the total_students variable in course by one, and add student to the array
 * of students in course
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
    course->total_students++;
  /**
   * @brief in this if statement calloc is used to request a block of memory on the heap 
   * (so that we can resize it with realloc later)
   * 
   */
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  /**
   * @brief on the other hand, if the if condition isn't true, 
   * realloc will resize the array to the new number of students (which is total_students)
   * 
   */
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  /**
   * @brief next, we assign the new student to the last element of the students array (thus enrolling this student)
   * 
   */
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This function will print the information of the course in an understandable manner
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  /**
   * @brief this for loop will go through each student in the students array and print the student using the print function
   * defined in student.c
   * 
   */
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This function utilizes the average function defined in student.c to search
 * and find the student with the highest average
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  /**
   * @brief if there are no students enrolled, then there cannot be a top student
   * 
   */
  if (course->total_students == 0) return NULL;
  
  /**
   * @brief the following three lines are to define the student average which will change as we iterate
   * through the students, max_average which assumes that the first student is the top student till it compares
   * the students average to student_average, and student is going to be the student we return (this will be coordinated with max_average)
   * 
   */
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  /**
   * @brief This for loop is going to iterate through each student in the course and compare the  
   * max_average to the current student's average, in order to find the highest average. if the student's average is
   * higher than max_average, it will become the new max_average and the variable student will be assigned to this student
   * making it potentially the one returned
   * 
   * @param i 
   */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief this function will return an array of all the passing students in a course
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  /**
   * @brief this for loop will iterate through all the students to determine how many are passing
   * 
   */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /**
   * @brief this following statement will make an array of size count (which is the number of passing students)
   * on the heap
   * 
   */
  passing = calloc(count, sizeof(Student));

  /**
   * @brief this for loop will go iterate through all of the students, and add the passing ones to the passing array
   * 
   */
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}