/**
 * @file main.c
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  /**
   * @brief Construct a new srand object, this is used to generate random numbers later in the code
   * 
   * @param unsigned 
   */
  srand((unsigned) time(NULL));

  /**
   * @brief the following three lines and for loop is used to create a course object and generate 8 random students
   * for this course (which is then printed)
   * 
   */
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  /**
   * @brief the next four lines are to determine and print the top student in the course above 
   * 
   */
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  /**
   * @brief the following 5 lines are to find the number of passing students in the course above and 
   * print said passing students 
   * 
   */
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}