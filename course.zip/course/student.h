/**
 * @file student.h
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief This typedef struct is made to store information about each student. Namely the first name, last name, 
 * student id, what will be an array of grades, and the amount of grades in the previous variable (array of grades)
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
